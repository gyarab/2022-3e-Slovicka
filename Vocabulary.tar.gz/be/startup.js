const SQLBuilder = require('./utils/SQLBuilder');
const db = new SQLBuilder();

async function startUp() {}

module.exports = {startUp}