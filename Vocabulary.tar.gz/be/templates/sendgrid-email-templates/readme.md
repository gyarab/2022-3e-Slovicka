# Sendgrid email templates

In this folder are stored sendgrid email templates only for backup and
easier editing dynamic templates. **These files are not used directly, 
use sendgrid api.** Names of these templates should match `env.sendgrid.templates (env file)`
template id names.