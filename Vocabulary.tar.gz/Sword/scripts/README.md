# SH scripts

How to use sh-scripts (build.sh, build-js.sh, build-styles.sh, init.sh, deploy-prep.sh, deploy-live.sh):
- all of them must be executed from root folder of a project
- variables should be modified before using

If files cannot be executed use `chmod +x filename` which
makes file executable. 

NOTE: Many of these files are used in package.json and can be called
from here.
